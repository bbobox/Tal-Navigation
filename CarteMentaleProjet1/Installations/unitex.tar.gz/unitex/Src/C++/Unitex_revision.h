#ifndef UnitexRevisionH
#define UnitexRevisionH

/* This file was overwritten by Unitex build server */
#define UNITEX_REVISION 3336
#define UNITEXREVISION 3336
#define UNITEX_REVISION_TEXT "3336"

#endif
